export interface queryColumnList{
    columnName: string;
    columnType: string;
    operator: operatorList[];
    distinctValues: dropDownValue[];
}

export interface operatorList {
    operatorValue: string;
    operatorName: string;
}

export interface dropDownValue {
    value: string;
    name: string;
}

