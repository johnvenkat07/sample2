import {
  ComponentRef,
  ComponentFactoryResolver,
  ViewContainerRef,
  ViewChild,
  Component,
  ViewRef,
  OnInit
} from "@angular/core";
import { queryColumnList } from "src/app/types/interface";
import { ChildComponent } from "../child/child.component";

@Component({
  selector: "app-parent",
  templateUrl: "./parent.component.html",
  styleUrls: ["./parent.component.css"]
})
export class ParentComponent implements OnInit {
  @ViewChild("viewContainerRef", { read: ViewContainerRef })
  VCR: ViewContainerRef;
  public queryColumnList: queryColumnList[];

  child_unique_key: number = 0;
  componentsReferences = Array<ComponentRef<ChildComponent>>()

  constructor(private CFR: ComponentFactoryResolver) { }

  ngOnInit(): void {
    this.queryColumnList = [{
      columnName: 'Gender',
      columnType: 'string',
      operator: [
        {
          operatorValue: 'equals',
          operatorName: '='
        },
        {
          operatorValue: 'greater',
          operatorName: '>'
        },
        {
          operatorValue: 'in',
          operatorName: 'IN'
        },

      ],
      distinctValues: [
        {
          value: 'Male',
          name: 'Male'
        },
        {
          value: 'Female',
          name: 'Female'
        }
      ]
    }]
  }

  createComponent() {
    let componentFactory = this.CFR.resolveComponentFactory(ChildComponent);

    let childComponentRef = this.VCR.createComponent(componentFactory);

    let childComponent = childComponentRef.instance;
    childComponent.unique_key = ++this.child_unique_key;
    childComponent.queryColumnList = this.queryColumnList
      childComponent.parentRef = this;

    // add reference for newly created component
    this.componentsReferences.push(childComponentRef);
  }

  remove(key: number) {

    console.log('11111key', key);

    if (this.VCR.length < 1) return;
    console.log('2222this.VCR.length', this.VCR.length);

    let componentRef = this.componentsReferences.find(
      x => x.instance.unique_key == key
    );
    console.log('333componentRef', componentRef);

    let vcrIndex: number = this.VCR.indexOf(componentRef.hostView as any);
    //let vcrIndex: number = this.VCR.detach()
    console.log('4444this.VCR', this.VCR);
    console.log('4444this.vcrIndex', vcrIndex);

    // removing component from container
    this.VCR.remove(vcrIndex);
    console.log('55');

    // removing component from the list
    this.componentsReferences = this.componentsReferences.filter(
      x => x.instance.unique_key !== key
    );
    console.log('666`');

  }
}
