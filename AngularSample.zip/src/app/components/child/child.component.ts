import { Component, OnInit, ComponentRef } from '@angular/core';
import { operatorList, queryColumnList } from 'src/app/types/interface';
import { ParentComponent } from '../parent/parent.component';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  public unique_key: number;
  public parentRef: ParentComponent;
  public queryColumnList: queryColumnList[];
  public columnName = '';
  public operator = '';
  public operatorDropdown: operatorList[];
  public userValue = '';


  constructor() {
  }
  ngOnInit(): void {
    console.log('queryColumnList', this.queryColumnList);
  }

  remove_me() {
    console.log(this.unique_key)
    console.log('columnName', this.columnName)
    console.log('operator', this.operator)
    //this.parentRef.remove(this.unique_key)
  }

  columnChanges(event) {
    console.log('event', event);
    this.operatorDropdown = this.queryColumnList.find(el => el.columnName === this.columnName).operator;
    console.log('operatorDropdown', this.operatorDropdown);

  }

  operatorChanges(event) {
    console.log('event', event);

  }

}