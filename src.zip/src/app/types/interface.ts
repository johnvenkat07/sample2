export interface Field{
    name: string;
    type: string;
    value?:string;
    // operator: operatorList[];
    operators?: string[]; 
    distinctValues?: option[];
}
export interface FieldMap {
    [key: string]: Field;
  }

export interface operatorList {
    name: string;
    value: string;
}

export interface option {
    value: string;
    name: string;
}

export interface QueryBuilderConfig {
    fields: FieldMap; 
  }

  export class Rule {
    field: string;
    value?: any;
    operator?: string;
    condition?: string;
  }
  export interface RuleSet {
    condition?: string;
    rules?:  Array<string | Rule>;
  }