import {
  ComponentRef,
  ComponentFactoryResolver,
  ViewContainerRef,
  ViewChild,
  Component,
  ViewRef,
  OnInit
} from "@angular/core";
import { QueryBuilderConfig } from "src/app/types/interface";
import { CriteriaComponent } from "../criteria/criteria.component";

@Component({
  selector: 'app-queryset',
  templateUrl: './queryset.component.html',
  styleUrls: ['./queryset.component.css']
})
export class QuerysetComponent implements OnInit {
  @ViewChild("viewContainerRef", { read: ViewContainerRef, static: false })
  VCR: ViewContainerRef;
  public queryBuilderConfig: QueryBuilderConfig;

  child_unique_key: number = 0;
  componentsReferences = Array<ComponentRef<CriteriaComponent>>()

  constructor(private CFR: ComponentFactoryResolver) { }

  ngOnInit(): void {
    this.queryBuilderConfig ={
       
      fields: {
        age: {name: 'Age', type: 'number'},
        gender: {
          name: 'Gender', 
          type: 'category',
          distinctValues: [
            {name: 'Male', value: 'm'},
            {name: 'Female', value: 'f'}
          ]
        },
        name: {name: 'Name', type: 'string' },
        notes: {name: 'Notes', type: 'string', operators: ['=', '!=']},
        educated: {name: 'College Degree?', type: 'boolean'},
        birthday: {name: 'Birthday', type: 'date', operators: ['=', '<=', '>']
        },
        school: {name: 'School', type: 'string'},
        occupation: {
          name: 'Occupation',
          type: 'category',
          distinctValues: [
            {name: 'Student', value: 'student'},
            {name: 'Teacher', value: 'teacher'},
            {name: 'Unemployed', value: 'unemployed'},
            {name: 'Scientist', value: 'scientist'}
          ]
        }
      }
    };
  }

  createCriteriaComponent() {
    let componentFactory = this.CFR.resolveComponentFactory(CriteriaComponent);

    let childComponentRef = this.VCR.createComponent(componentFactory);

    let childComponent = childComponentRef.instance;
    childComponent.unique_key = ++this.child_unique_key;
    childComponent.queryBuilderConfig = this.queryBuilderConfig
    childComponent.parentRef = this;

    // add reference for newly created component
    this.componentsReferences.push(childComponentRef);
  }

  remove(key: number) {

    //console.log('11111key', key);

    if (this.VCR.length < 1) return;
    //console.log('2222this.VCR.length', this.VCR.length);

    let componentRef = this.componentsReferences.find(
      x => x.instance.unique_key == key
    );
    //console.log('333componentRef', componentRef);

    let vcrIndex: number = this.VCR.indexOf(componentRef.hostView as any);
    //let vcrIndex: number = this.VCR.detach()
    //console.log('4444this.VCR', this.VCR);
    //console.log('4444this.vcrIndex', vcrIndex);

    // removing component from container
    this.VCR.remove(vcrIndex);
    //console.log('55');

    // removing component from the list
    this.componentsReferences = this.componentsReferences.filter(
      x => x.instance.unique_key !== key
    );
    //console.log('666`');

  }
}
