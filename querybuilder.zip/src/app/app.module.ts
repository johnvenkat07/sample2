import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSelectModule } from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import { QuerysetComponent } from './components/queryset/queryset.component';
import { CriteriaComponent } from './components/criteria/criteria.component';
import { MatButtonModule } from '@angular/material';
import {MatIconModule} from '@angular/material/icon';
@NgModule({
  declarations: [ 
    AppComponent,
    QuerysetComponent,
    CriteriaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatSelectModule,MatInputModule,MatButtonModule,MatIconModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [
    CriteriaComponent
  ],
})
export class AppModule { }
