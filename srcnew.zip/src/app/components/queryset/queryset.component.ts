import {
  ComponentRef,
  ComponentFactoryResolver,
  ViewContainerRef,
  ViewChild,
  Component,
  ViewRef,
  OnInit, AfterViewInit, AfterContentChecked
  , DoCheck, KeyValueDiffers, KeyValueDiffer, Input, ChangeDetectorRef
} from "@angular/core";
import { QueryBuilderConfig, Rule, Rules } from "src/app/types/interface";
import { CriteriaComponent } from "../criteria/criteria.component";
import { SuperquerysetComponent } from "../superqueryset/superqueryset.component";

@Component({
  selector: 'app-queryset',
  templateUrl: './queryset.component.html',
  styleUrls: ['./queryset.component.css']
})
export class QuerysetComponent implements OnInit, AfterViewInit, AfterContentChecked {
  public unique_key: number;
  public parentRef: SuperquerysetComponent;
  @ViewChild("viewContainerRef", { read: ViewContainerRef, static: false })
  VCR: ViewContainerRef;
  @Input() queryBuilderConfig: QueryBuilderConfig = { fields: {} };
  @Input() ruleSet: Rules = {  rules: [],condition:'' };

  public ruleSetOut: Rules = {  rules: [],condition:'' };

  public defaultCondition: string = 'and';
  public selectParentCondition: string = '';
  child_unique_key: number = 0;
  componentsReferences = Array<ComponentRef<CriteriaComponent>>()
  differ: KeyValueDiffer<string, any>;
  constructor(private CFR: ComponentFactoryResolver, private differs: KeyValueDiffers, private changeDetectorRef: ChangeDetectorRef) {
    this.differ = this.differs.find({}).create();
  }
  ngAfterContentChecked(): void {
    this.changeDetectorRef.detectChanges();
    //throw new Error("Method not implemented.");
  }

  ngDoCheck() {
    const change = this.differ.diff(this);
    if (change) {
      this.generateRulesetOutput();
      this.parentRef.generateRuleset();
      this.parentRef.generateRulesetOutput();
    }
  }
  ngOnInit(): void {
this.selectParentCondition=this.ruleSet.condition;
  }
  ngAfterViewInit() {

    if (this.ruleSet.rules.length == 0) { this.createCriteriaComponent(); }
    else {
      this.generateRuleComponenetForInput(this.ruleSet);
    }
  }
  createCriteriaComponent(rule?: Rule) {
    let componentFactory = this.CFR.resolveComponentFactory(CriteriaComponent);

    let childComponentRef = this.VCR.createComponent(componentFactory);

    let childComponent = childComponentRef.instance;
    childComponent.unique_key = ++this.child_unique_key;
    childComponent.queryBuilderConfig = this.queryBuilderConfig
    childComponent.parentRef = this;
    //childComponent.selectedCondition = '';
    childComponent.rule = !rule ? { field: '', operator: '', value: '', condition: '' } : rule;
    // add reference for newly created component
    this.componentsReferences.push(childComponentRef);
    //this.updateChild()
  }

  remove(key: number) {

    if (this.componentsReferences.length > 1) {
      if (this.VCR.length < 1) return;

      let componentRef = this.componentsReferences.find(
        x => x.instance.unique_key == key
      );

      let vcrIndex: number = this.VCR.indexOf(componentRef.hostView as any);
      //let vcrIndex: number = this.VCR.detach()


      // removing component from container
      this.VCR.remove(vcrIndex);

      // removing component from the list
      this.componentsReferences = this.componentsReferences.filter(
        x => x.instance.unique_key !== key
      );
      this.generateRuleset();

    }
  }
  updateChild() {
    //console.log(this.componentsReferences);
    for (let index = 0; index < this.componentsReferences.length; index++) {
      const element = this.componentsReferences[index];
      if (index == this.componentsReferences.length - 1) {
        element.instance.rule.condition = '';
      } else {
        if (!element.instance.rule.condition)
          element.instance.rule.condition = this.defaultCondition;
      }
    }
  }
  generateRuleset() {
    this.updateChild();
    this.ruleSet = {  rules: [],condition:this.selectParentCondition };
    this.componentsReferences.forEach(element => {
      this.ruleSet.rules.push(element.instance.rule);
    });
  }
  generateRulesetOutput() {
    //this.updateChild();
    this.ruleSetOut = { rules: [],condition:this.selectParentCondition };
    this.componentsReferences.forEach(element => {
      let rule = Object.assign({}, element.instance.rule);
      let condition: string = rule.condition;
      delete rule.condition;
      this.ruleSetOut.rules.push(rule);
      this.ruleSetOut.rules.push(condition);
    });
  }
  generateRuleComponenetForInput(rule: Rules) {
    //this.ruleSetIn = { rules: [] };
    for (let index = 0; index < rule.rules.length; index++) {
      const element = rule.rules[index];
      if (!(element as Rule).field) {
        (rule.rules[index - 1] as Rule).condition = element.toString();
        delete rule.rules[index];
      }
    }
    rule.rules.forEach(element => {
      this.createCriteriaComponent(element as Rule);
      //this.ruleSetIn.rules.push(element);
    });
  }
  remove_me() {
    this.parentRef.remove(this.unique_key)
  }
}
