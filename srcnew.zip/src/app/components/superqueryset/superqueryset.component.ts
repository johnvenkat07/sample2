import { AfterContentChecked, AfterViewInit, ChangeDetectorRef, Component, ComponentFactoryResolver, ComponentRef, Input, KeyValueDiffer, KeyValueDiffers, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { QueryBuilderConfig, Rules, RuleSet } from 'src/app/types/interface';
import { QuerysetComponent } from '../queryset/queryset.component';

@Component({
  selector: 'app-superqueryset',
  templateUrl: './superqueryset.component.html',
  styleUrls: ['./superqueryset.component.css']
})
export class SuperquerysetComponent implements OnInit, AfterViewInit, AfterContentChecked {

  @ViewChild("viewContainerRef", { read: ViewContainerRef, static: false })
  VCR: ViewContainerRef;
  @Input() queryBuilderConfig: QueryBuilderConfig = { fields: {} };
  @Input() ruleSet: RuleSet = { rules: [] };
  public ruleSetOut: RuleSet = {  rules: [],condition:'' };

  rulechild: Rules = { rules: [] };
  public defaultCondition: string = 'and';
  child_unique_key: number = 0;
  componentsReferences = Array<ComponentRef<QuerysetComponent>>()
  differ: KeyValueDiffer<string, any>;
  constructor(private CFR: ComponentFactoryResolver, private differs: KeyValueDiffers, private changeDetectorRef: ChangeDetectorRef) {
    this.differ = this.differs.find({}).create();
  }
  ngAfterContentChecked(): void {
    this.changeDetectorRef.detectChanges();
    //throw new Error("Method not implemented.");
  }

  ngDoCheck() {
    const change = this.differ.diff(this);
    if (change) {
      this.generateRulesetOutput();
    }
  }
  ngOnInit(): void {

  }
  ngAfterViewInit() {
    if (this.ruleSet.rules.length == 0) { this.createCriteriaComponent(this.ruleSet); }
    else {
      this.generateRuleComponenetForInput(this.ruleSet);
    }
    // this.createCriteriaComponent(this.ruleSet);

  }
  createCriteriaComponent(rule?: RuleSet) {
    let componentFactory = this.CFR.resolveComponentFactory(QuerysetComponent);

    let childComponentRef = this.VCR.createComponent(componentFactory);

    let childComponent = childComponentRef.instance;
    childComponent.unique_key = ++this.child_unique_key;
    childComponent.queryBuilderConfig = this.queryBuilderConfig
    childComponent.parentRef = this;
    childComponent.ruleSet = !rule as Rules ? this.rulechild : rule as Rules;
    // add reference for newly created component
    this.componentsReferences.push(childComponentRef);
    //this.updateChild()
  }
  remove(key: number) {

    if (this.componentsReferences.length > 1) {
      if (this.VCR.length < 1) return;

      let componentRef = this.componentsReferences.find(
        x => x.instance.unique_key == key
      );

      let vcrIndex: number = this.VCR.indexOf(componentRef.hostView as any);
      //let vcrIndex: number = this.VCR.detach()


      // removing component from container
      this.VCR.remove(vcrIndex);

      // removing component from the list
      this.componentsReferences = this.componentsReferences.filter(
        x => x.instance.unique_key !== key
      );
      this.updateChild();
    }
  }
  generateRuleComponenetForInput(rule: RuleSet) {
    //this.ruleSetIn = { rules: [] };
    for (let index = 0; index < rule.rules.length; index++) {
      const element = rule.rules[index];
      if (!(element as RuleSet).rules) {
        (rule.rules[index - 1] as RuleSet).condition = element.toString();
        delete rule.rules[index];
      }
    }
    rule.rules.forEach(element => {
      this.createCriteriaComponent(element as RuleSet);
      //this.ruleSetIn.rules.push(element);
    });
  }

  updateChild() {
    //console.log(this.componentsReferences);
    for (let index = 0; index < this.componentsReferences.length; index++) {
      const element = this.componentsReferences[index];
      if (index == this.componentsReferences.length - 1) {
        element.instance.ruleSet.condition = '';
        element.instance.selectParentCondition = '';

      } else {
        if (!element.instance.ruleSet.condition)
          element.instance.ruleSet.condition = this.defaultCondition;
          element.instance.selectParentCondition = this.defaultCondition;
      }
    }
  }
  generateRuleset() {
    this.updateChild();
    this.ruleSet = { rules: [] };
    this.componentsReferences.forEach(element => {
      this.ruleSet.rules.push(element.instance.ruleSet);
    });
  }
  generateRulesetOutput() {
    //this.updateChild();
    this.ruleSetOut = { rules: [] };
    this.componentsReferences.forEach(element => {
      let rule = Object.assign({}, element.instance.ruleSetOut);
      let condition: string = rule.condition;
      delete rule.condition;
      this.ruleSetOut.rules.push(rule);
      this.ruleSetOut.rules.push(condition);
    });
  }
}
