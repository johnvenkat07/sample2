import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperquerysetComponent } from './superqueryset.component';

describe('SuperquerysetComponent', () => {
  let component: SuperquerysetComponent;
  let fixture: ComponentFixture<SuperquerysetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperquerysetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperquerysetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
