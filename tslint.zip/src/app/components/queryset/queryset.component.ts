import {
  ComponentRef,
  ComponentFactoryResolver,
  ViewContainerRef,
  ViewChild,
  Component,
  ViewRef,
  OnInit, AfterViewInit
  , DoCheck, KeyValueDiffers, KeyValueDiffer, Input
} from "@angular/core";
import { QueryBuilderConfig, Rule, RuleSet } from "src/app/types/interface";
import { CriteriaComponent } from "../criteria/criteria.component";

@Component({
  selector: 'app-queryset',
  templateUrl: './queryset.component.html',
  styleUrls: ['./queryset.component.css']
})
export class QuerysetComponent implements OnInit, AfterViewInit {
  @ViewChild("viewContainerRef", { read: ViewContainerRef, static: false })
  VCR: ViewContainerRef;
  @Input() queryBuilderConfig: QueryBuilderConfig = { fields: {} };
  @Input() ruleSet: RuleSet={condition:'and',rules:[]};
  
  public selectedCondition: string = 'and';
  child_unique_key: number = 0;
  componentsReferences = Array<ComponentRef<CriteriaComponent>>()
  differ: KeyValueDiffer<string, any>;
  constructor(private CFR: ComponentFactoryResolver, private differs: KeyValueDiffers) {
    this.differ = this.differs.find({}).create();
  }
  // public queryBuilderConfig: QueryBuilderConfig = {

  //   fields: {
  //     age: { name: 'Age', type: 'number' },
  //     gender: {
  //       name: 'Gender',
  //       type: 'category',
  //       distinctValues: [
  //         { name: 'Male', value: 'm' },
  //         { name: 'Female', value: 'f' }
  //       ]
  //     },
  //     name: { name: 'Name', type: 'string' },
  //     notes: { name: 'Notes', type: 'string', operators: ['=', '!='] },
  //     educated: { name: 'College Degree?', type: 'boolean' },
  //     birthday: {
  //       name: 'Birthday', type: 'date', operators: ['=', '<=', '>']
  //     },
  //     school: { name: 'School', type: 'string' },
  //     occupation: {
  //       name: 'Occupation',
  //       type: 'category',
  //       distinctValues: [
  //         { name: 'Student', value: 'student' },
  //         { name: 'Teacher', value: 'teacher' },
  //         { name: 'Unemployed', value: 'unemployed' },
  //         { name: 'Scientist', value: 'scientist' }
  //       ]
  //     }
  //   }
  // };



  //public ruleSet: RuleSet={condition:'and',rules:[]};
  // public ruleSet: RuleSet = {
  //   condition: 'and',
  //   rules: [
  //     {
  //       field: 'age',
  //       operator: '<=',
  //       value: '5'
  //     },
  //     {
  //       field: 'birthday',
  //       operator: '=',
  //       value: '2021-02-09',
  //     },
  //     {
  //       field: 'notes',
  //       operator: '=',
  //       value: 'teew'
  //     },
  //     {
  //       field: 'occupation',
  //       operator: 'in',
  //       value: [
  //         'student',
  //         'teacher'
  //       ]
  //     }
  //   ]
  // }

  ngDoCheck() {
    const change = this.differ.diff(this);
    if (change) {
     // this.generateRuleset();
    }
  }
  ngOnInit(): void {

  }
  ngAfterViewInit() {
    if (this.ruleSet.rules.length == 0) { this.createCriteriaComponent(); }
    else {
      this.ruleSet.rules.forEach(rule => {
        this.createCriteriaComponent(rule);
      });
    }
  }
  createCriteriaComponent(rule?: Rule) {
    let componentFactory = this.CFR.resolveComponentFactory(CriteriaComponent);

    let childComponentRef = this.VCR.createComponent(componentFactory);

    let childComponent = childComponentRef.instance;
    childComponent.unique_key = ++this.child_unique_key;
    childComponent.queryBuilderConfig = this.queryBuilderConfig
    childComponent.parentRef = this;
    childComponent.selectedCondition = '';
    childComponent.rule = !rule ? { field: '', operator: '', value: '' } : rule;
    // add reference for newly created component
    this.componentsReferences.push(childComponentRef);
    this.updateChild()
  }

  remove(key: number) {

    //console.log('11111key', key);
    if (this.componentsReferences.length > 1) {
      if (this.VCR.length < 1) return;
      //console.log('2222this.VCR.length', this.VCR.length);

      let componentRef = this.componentsReferences.find(
        x => x.instance.unique_key == key
      );
      //console.log('333componentRef', componentRef);

      let vcrIndex: number = this.VCR.indexOf(componentRef.hostView as any);
      //let vcrIndex: number = this.VCR.detach()
      //console.log('4444this.VCR', this.VCR);
      //console.log('4444this.vcrIndex', vcrIndex);

      // removing component from container
      this.VCR.remove(vcrIndex);
      //console.log('55');

      // removing component from the list
      this.componentsReferences = this.componentsReferences.filter(
        x => x.instance.unique_key !== key
      );
      //console.log('666`');
      this.updateChild();
    }
  }
  updateChild() {
    console.log(this.componentsReferences);
    for (let index = 0; index < this.componentsReferences.length; index++) {
      const element = this.componentsReferences[index];
      if (index == this.componentsReferences.length - 1) {
        element.instance.selectedCondition = '';
      } else {
        element.instance.selectedCondition = this.selectedCondition;
      }
    }


  }
  generateRuleset() {
    this.ruleSet = { condition: this.selectedCondition, rules: [] };
    this.componentsReferences.forEach(element => {
      this.ruleSet.rules.push(element.instance.rule);
    });
  }
}
