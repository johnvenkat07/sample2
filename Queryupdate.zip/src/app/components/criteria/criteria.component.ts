import { Component, OnInit, DoCheck, KeyValueDiffers, KeyValueDiffer ,AfterContentChecked,ChangeDetectorRef} from '@angular/core';
import { Field, option, QueryBuilderConfig, Rule } from 'src/app/types/interface';
import { QuerysetComponent } from '../queryset/queryset.component';


@Component({
  selector: 'app-criteria',
  templateUrl: './criteria.component.html',
  styleUrls: ['./criteria.component.css']
})
export class CriteriaComponent implements OnInit ,AfterContentChecked{

  public unique_key: number;
  public parentRef: QuerysetComponent;
  public queryBuilderConfig: QueryBuilderConfig;
  public selectedCondition: string;
  public rule: Rule;
  public fields: Field[];
  public operators: string[];
  public distinctValues: option[];
  public fieldtype: string;
  public defaultOperatorMap: { [key: string]: string[] } = {
    string: ['=', '!=', 'contains'],
    number: ['=', '!=', '>', '>=', '<', '<='],
    date: ['=', '!=', '>', '>=', '<', '<='],
    category: ['=', '!=', 'in', 'not in'],
    boolean: ['is']
  };

  differ: KeyValueDiffer<string, any>;
  constructor(private differs: KeyValueDiffers,private changeDetectorRef:ChangeDetectorRef) {
    this.differ = this.differs.find({}).create();
  }
  ngDoCheck() {
    const change = this.differ.diff(this);
    if (change) {
      this.parentRef.generateRuleset();
    }
  }
  ngAfterContentChecked(): void {
    this.changeDetectorRef.detectChanges();
    //throw new Error("Method not implemented.");
  }
  ngOnInit(): void {
    const config = this.queryBuilderConfig;
    const type = typeof config;
    if (type === 'object') {
      this.fields = Object.keys(config.fields).map((value) => {
        const field = config.fields[value];
        field.value = field.value || value;
        return field;
      });

    } else {
      throw new Error(`Expected 'config' must be a valid object, got ${type} instead.`);
    }
    if (this.rule.field) {
      this.getOperators();
      this.getOptions();
    }
   }
  remove_me() {
    this.parentRef.remove(this.unique_key)
  }
  fieldChange() {
    this.rule.operator = '';
    this.rule.value = '';
    this.getOperators();
  }
  getOperators() {
    const fieldObject = this.queryBuilderConfig.fields[this.rule.field];
    const type = fieldObject.type;
    if (fieldObject && fieldObject.operators) {
      this.operators = fieldObject.operators;
    } else if (type) {
      this.operators = this.defaultOperatorMap[type]

    } else {
      console.warn(`No 'type' property found on field: '${this.rule.field}'`);
    }
  }
  operatorChange() {
    this.rule.value = '';
    this.getOptions();
  }
  getInputType() {
    if (this.rule.field) {
      const type = this.queryBuilderConfig.fields[this.rule.field].type;
      switch (this.rule.operator) {
        case 'in':
        case 'not in':
          return type === 'category' ? 'multiselect' : type;
        default:
          return type;
      }
    }
  }
  getOptions() {
    this.distinctValues = this.queryBuilderConfig.fields[this.rule.field].distinctValues;
  }
}
