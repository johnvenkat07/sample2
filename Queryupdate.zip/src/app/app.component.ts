import { Component } from '@angular/core';
import { QueryBuilderConfig, Rule, RuleSet } from "src/app/types/interface";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'querybuilder';
  public queryBuilderConfig: QueryBuilderConfig = {

    fields: {
      age: { name: 'Age', type: 'number' },
      gender: {
        name: 'Gender',
        type: 'category',
        distinctValues: [
          { name: 'Male', value: 'm' },
          { name: 'Female', value: 'f' }
        ]
      },
      name: { name: 'Name', type: 'string' },
      notes: { name: 'Notes', type: 'string', operators: ['=', '!='] },
      educated: { name: 'College Degree?', type: 'boolean' },
      birthday: {
        name: 'Birthday', type: 'date', operators: ['=', '<=', '>']
      },
      school: { name: 'School', type: 'string' },
      occupation: {
        name: 'Occupation',
        type: 'category',
        distinctValues: [
          { name: 'Student', value: 'student' },
          { name: 'Teacher', value: 'teacher' },
          { name: 'Unemployed', value: 'unemployed' },
          { name: 'Scientist', value: 'scientist' }
        ]
      }
    }
  };
  public ruleSet: RuleSet = {
    condition: 'and',
    rules: [
      {
        field: 'age',
        operator: '<=',
        value: '15'
      },
      {
        field: 'birthday',
        operator: '=',
        value: '2021-02-09',
      },
      {
        field: 'notes',
        operator: '=',
        value: 'teew'
      },
      {
        field: 'occupation',
        operator: 'in',
        value: [
          'student',
          'teacher'
        ]
      },
      {
        field: 'age',
        operator: '=',
        value: '15'
      },
    ]
  }
}
